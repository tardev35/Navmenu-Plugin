<?php
/*
Plugin Name: Change Link V.2
Description: แก้ไขลิงก์ a href 
Version: 2.0
Author: อิชิตันมันจังเอย
*/


add_action('admin_menu', function() {
    add_menu_page(
        'Change Link',
        'Change Link',
        'manage_options',
        'change-link',
        'cla_settings_page'
    );
});


function cla_settings_page() {
    ?>
    <div class="wrap">
        <style> 
input.cla_signup {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
}
</style>
        <h2>Change Link</h2>
        <form method="post" action="options.php">
            <?php
            settings_fields('cla-options');
            do_settings_sections('cla-options');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Sign In URL</th>
                    <td><input type="text" name="cla_signin" style="width: 500px;" value="<?php echo esc_attr(get_option('cla_signin', '/signin')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Sign Up URL</th>
                    <td><input type="text" name="cla_signup" style="width: 500px;" value="<?php echo esc_attr(get_option('cla_signup', '')); ?>" /></td>
                </tr>
            </table>
            <input type="submit" class="button button-primary" value="SAVE" />
        </form>
    </div>
    <?php
}


add_action('admin_init', function() {
    register_setting('cla-options', 'cla_signin');
    register_setting('cla-options', 'cla_signup');
});

function custom_change_link_href($content) {
    $signin = get_option('cla_signin', '/signin');
    $signup = get_option('cla_signup', '/signup');

    $content = preg_replace('/<a\s+href="\/signin"/', '<a href="' . esc_url($signin) . '"', $content);
 
    $content = preg_replace('/<a\s+href="\/signup"/', '<a href="' . esc_url($signup) . '"', $content);

    return $content;
}
function global_change_signin_signup_links($buffer) {
    $signin = get_option('cla_signin', '/signin');
    $signup = esc_js(get_option('cla_signup', '/signup'));
    $buffer = preg_replace('/<a\s+([^>]*?)href="\/signin"/i', '<a $1href="' . esc_url($signin) . '"', $buffer);
    $buffer = preg_replace('/<a\s+([^>]*?)href="\/signup"/i', '<a $1href="' . esc_url($signup) . '"', $buffer);
    return $buffer;
}

if (!is_admin()) {
    add_action('template_redirect', function() {
        ob_start('global_change_signin_signup_links');
    });
}

add_action('wp_footer', function() {
    $signup = get_option('cla_signup', '/signup'); 
    ?>
    <script>
    console.log("DEBUG signup: ", '<?php echo $signup; ?>');
    function fixSigninSignupLinks() {
        document.querySelectorAll('a[href]').forEach(function(a){
            var href = a.getAttribute('href');
            if (/\/signup(\?|\/|$)/.test(href)) {
                a.setAttribute('href', '<?php echo $signup; ?>');
            }
        });
    }
    fixSigninSignupLinks();
    document.addEventListener('DOMContentLoaded', fixSigninSignupLinks);
    document.addEventListener('ux_ajax_loaded', fixSigninSignupLinks); 
    setInterval(fixSigninSignupLinks, 1000);
    </script>
    <?php
});







