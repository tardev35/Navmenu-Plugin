<?php
/**
 * Plugin Name: Nav Menu Style Red Pink
 * Description: Adds a custom footer Nav Menu Style Pink, and contact buttons.
 * Version: 1.0
 * Author: Niran.TH
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Enqueue CSS
function cfw_enqueue_styles() {
    wp_enqueue_style('cfw-style', plugin_dir_url(__FILE__) . 'assets/style2.css' , array(),'1.2');
}
add_action('wp_enqueue_scripts', 'cfw_enqueue_styles');

// Register shortcode
function navstyle_1() {
    ob_start();
    ?>
    <div class="x-button-actions" id="account-actions-mobile">
       <div class="-outer-wrapper">
          <div class="-left-wrapper">
             <span class="-item-wrapper"><span class="-ic-img"><a href="/signin"><span class="-textfooter d-block">เข้าสู่ระบบ</span></a><a href="/signin"><img src="https://i.imgur.com/R6MGUPS.png?v=1.1"></a></span></span>
             <span class="-item-wrapper"><span class="-ic-img"><a href="/signup"><span class="-textfooter d-block">สมัคร</span></a><a href="/signup"><img src="https://i.imgur.com/9gMcJB0.png?v=1.1"></a></span></span>        
          </div>
          <span class="-center-wrapper js-footer-lobby-selector js-menu-mobile-container">
              <div class="-selected"><span style="font-size: 13px;" class="widgettitle">เข้าเล่น</span>
            <a href="/signup">  <img width="121" height="121" src="https://i.imgur.com/7Z0kx5E.png?v=1.1"> </a></div>            
          </span>
          <div class="-fake-center-bg-wrapper">
             <svg viewBox="-10 -1 30 12">
                <defs>
                   <linearGradient id="rectangleGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stop-color="#5c001d"></stop>
                      <stop offset="100%" stop-color="#5c001d"></stop>
                   </linearGradient>
                </defs>
                <path d="M-10 -1 H30 V12 H-10z M 5 5 m -5, 0 a 5,5 0 1,0 10,0 a 5,5 0 1,0 -10,0z"></path>
             </svg>
          </div>
          <div class="-right-wrapper">
            <span class="-item-wrapper"><span class="-ic-img"><a href="/promotion"><span class="-textfooter d-block">โปรโมชั่น</span></a><a href="/promotion"><img width="258" height="257" src="https://i.imgur.com/4lwdukW.png?v=1.1"></a></span></span>
            <span class="-item-wrapper"><span class="-ic-img"><a href="/line"><span class="-textfooter d-block">ติดต่อเรา</span></a><a href="/line"><img width="123" height="122" src="https://i.imgur.com/AFU9WMb.png?v=1.1"></a></span></span>
          </div>
          <div class="-fully-overlay js-footer-lobby-overlay"></div>
       </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('navstyle', 'navstyle_1');
